import pygame
from asset_loader import asset_load_character, asset_load_character_flipped

from pytmx.util_pygame import load_pygame
class Game:
    def __init__(self):
        pygame.init()
        self.infoObject = pygame.display.Info()
        self.sw = 1024
        self.sh = 768
        print(self.sh)
        self.screen = pygame.display.set_mode((self.sw, self.sh))
        pygame.display.set_caption('BomberGuy', icontitle='BG')
        self.image = pygame.image.load('Assets/Startup/icon.png').convert_alpha()
        pygame.display.set_icon(self.image)
        self.clock = pygame.time.Clock()
        self.clock = pygame.time.Clock()
        self.fps = 30
        self.running = True
        self.alpha = 0
        self.begin = True
        self.animating = False
        self.fading = False
        self.slow = 0.5

    # Logo
        self.logo = pygame.image.load('Assets/Startup/logo.png').convert_alpha()
        self.logo = pygame.transform.scale(self.logo, (250, 250))
        self.logo_rect = self.logo.get_rect(center=(self.sw/2, self.sh/2))

    # Character/Player
        images = asset_load_character("Red")
        flipped_images = asset_load_character_flipped("Red")
        image = images[0][0]

        # Player 2
        images2 = asset_load_character("Blue")
        flipped_images2 = asset_load_character_flipped("Blue")
        image2 = images2[0][0]

        #Player 3
        images3 = asset_load_character("Yellow")
        flipped_images3 = asset_load_character_flipped("Yellow")
        image3 = images3[0][0]

        #Player 4
        images4 = asset_load_character("Green")
        flipped_images4 = asset_load_character_flipped("Green")
        image4 = images4[0][0]

        #All Players
        image_rect = image.get_rect(center=(self.sw/2, self.sh/2))
        image_rect2 = image.get_rect(center=(self.sw/2 + 10, self.sh/2))
        image_rect3 = image.get_rect(center=(self.sw / 2 + 20, self.sh / 2))
        image_rect4 = image.get_rect(center=(self.sw / 2 + 30, self.sh / 2))
        self.character1 = pygame.sprite.GroupSingle()
        self.character1.add(Player(image, image_rect, images, flipped_images, 5))
        self.character2 = pygame.sprite.GroupSingle()
        self.character2.add(Player2(image2, image_rect2, images2, flipped_images2, 5))
        self.character3 = pygame.sprite.GroupSingle()
        self.character3.add(Player3(image3, image_rect3, images3, flipped_images3, 5))
        self.character4 = pygame.sprite.GroupSingle()
        self.character4.add(Player4(image4, image_rect4, images4, flipped_images4, 5))

        self.players = [self.character1.sprite]

        self.tiles = pygame.sprite.Group()
        self.map = load_pygame('Assets/Tiled/trial.tmx')
        for layer in self.map.visible_layers:
            for x, y, image in layer.tiles():
                self.tiles.add(Tiles(image, x, y))

    def main(self):
        while self.running:
            self.clock.tick(self.fps)
            self.screen.fill('Black')
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN:
                    # Player 1
                    if event.key == pygame.K_KP8:
                        if self.character1.sprite.grounded:
                            self.character1.sprite.func_jumped()
                        elif not self.character1.sprite.grounded and not self.character1.sprite.is_double_jumped:
                            self.character1.sprite.func_double_jumped()
                    if event.key == pygame.K_KP5 and self.character1.sprite.cooldown <= 0:
                        self.character1.sprite.is_dashing = True
                        self.character1.sprite.rolled = True
                        self.character1.sprite.double_jump_index = 0
                    # Player 2
                    if event.key == pygame.K_UP:
                        if self.character2.sprite.grounded:
                            self.character2.sprite.func_jumped()
                        elif not self.character2.sprite.grounded and not self.character2.sprite.is_double_jumped:
                            self.character2.sprite.func_double_jumped()
                    if event.key == pygame.K_DOWN and self.character2.sprite.cooldown <= 0:
                        self.character2.sprite.is_dashing = True
                        self.character2.sprite.rolled = True
                        self.character2.sprite.double_jump_index = 0
                    #Player 3
                    if event.key == pygame.K_w:
                        if self.character3.sprite.grounded:
                            self.character3.sprite.func_jumped()
                        elif not self.character3.sprite.grounded and not self.character3.sprite.is_double_jumped:
                            self.character3.sprite.func_double_jumped()
                    if event.key == pygame.K_s and self.character3.sprite.cooldown <= 0:
                        self.character3.sprite.is_dashing = True
                        self.character3.sprite.rolled = True
                        self.character3.sprite.double_jump_index = 0
                    #Player 4
                    if event.key == pygame.K_i:
                        if self.character4.sprite.grounded:
                            self.character4.sprite.func_jumped()
                        elif not self.character4.sprite.grounded and not self.character4.sprite.is_double_jumped:
                            self.character4.sprite.func_double_jumped()
                    if event.key == pygame.K_k and self.character4.sprite.cooldown <= 0:
                        self.character4.sprite.is_dashing = True
                        self.character4.sprite.rolled = True
                        self.character4.sprite.double_jump_index = 0

            if self.begin:
                if self.fading:
                    self.fade_out()
                else:
                    self.fade_in()
            else:
                self.tiles.update()
                #self.character4.update()
                #self.character3.update()
                #self.character2.update()
                self.character1.update()
                self.collision()
                self.tiles.draw(self.screen)
               # self.character4.draw(self.screen)
                #self.character3.draw(self.screen)
                #self.character2.draw(self.screen)
                self.character1.draw(self.screen)

            pygame.display.flip()

    def collision(self):
        for player in self.players:
            collision = pygame.sprite.spritecollide(player, self.tiles, False)
            if collision:
                top = []
                bottom = []
                left = []
                right = []

                for tile in collision:
                # 1. Calculate Overlap
                    overlap_x = min(player.rect.right, tile.rect.right) - max(player.rect.left, tile.rect.left)
                    overlap_y = min(player.rect.bottom, tile.rect.bottom) - max(player.rect.top, tile.rect.top)

                    # 2. Determine Collision Axis
                    if overlap_x < overlap_y:
                        # Horizontal Collision (Left/Right)
                        if player.rect.centerx < tile.rect.centerx:
                            left.append(tile)
                        else:
                            right.append(tile) # Player hit the right side of the tile

                    else:
                        # Vertical Collision (Top/Bottom)
                        if player.rect.centery < tile.rect.centery:
                            top.append(tile)
                        else:
                            bottom.append(tile)






    @staticmethod
    def rect_combine(rects):
        union = None
        for i in range(len(rects) - 1):
            union = rects[i].rect.union(rects[i + 1].rect)

        return union



    def fade_in(self):
        self.alpha += 3.5
        if self.alpha > 255:
            self.alpha = 255
            self.fading = True
        self.logo.set_alpha(self.alpha)
        self.screen.blit(self.logo, self.logo_rect)

    def fade_out(self):
        self.alpha -= 3.5
        if self.alpha <= 0:
            self.alpha = 0
            self.fading = False
            self.begin = False
        self.logo.set_alpha(self.alpha)
        self.screen.blit(self.logo, self.logo_rect)


class Tiles(pygame.sprite.Sprite):
    def __init__(self, image, x, y):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(topleft=(x * 16, y * 16))


class Player(pygame.sprite.Sprite):
    def __init__(self, image, rect, images, flipped_images, max_hp=5):
        super().__init__()
        self.images = images
        self.flipped_images = flipped_images
        self.image_bank = self.images
        self.flipped = False
        self.image = image
        self.rect = rect
        self.max_hp = max_hp
        self.hp = self.max_hp
        self.is_dashing = False
        self.direction = 1
        self.dash_frame = 0
        self.cooldown = 0
        self.gravity = 0
        self.grounded = False
        self.is_double_jumped = True
        self.run_index = 0
        self.idle_index = 0
        self.double_jump_index = 0
        self.jumped = True
        self.rolled = False
        self.collide = False
        self.dx = 0
        self.dy = 0
        self.float = False

    def controls(self):
        keys = pygame.key.get_pressed()

        if self.is_dashing:
            self.dash()
            self.cooldown = 2
        else:
            if keys[pygame.K_KP4]:
                self.idle_index = 0
                self.dx = 4
                self.rect.centerx -= self.dx
                self.direction = -1
                self.flipped = True
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]

            elif keys[pygame.K_KP6]:
                self.idle_index = 0
                self.dx = 4
                self.rect.centerx += self.dx
                self.direction = 1
                self.flipped = False
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]
            else:
                self.run_index = 0
                self.idle_index += 1/3
                if self.idle_index > len(self.image_bank[0]):
                    self.idle_index = 0
                self.image = self.image_bank[0][int(self.idle_index)]

            self.cooldown -= 1/60

    def dash(self):
        self.dx = 12
        self.rect.centerx += self.dx * self.direction
        self.dash_frame += 1
        # Got Hit
        #If pygame.rect.collide:
        if self.dash_frame >= 5:
            self.is_dashing = False
            self.dash_frame = 0
            self.dx = 0

    def animation(self):
        #if hit : pass

        if self.is_double_jumped and not self.rolled:
            self.double_jump_index += 1 / 3
            if self.double_jump_index > len(self.image_bank[4]):
                self.double_jump_index = 0
                self.rolled = True
            self.image = self.image_bank[4][int(self.double_jump_index)]
        elif not self.grounded and self.gravity < 0:
            self.image = self.image_bank[2][0]
        elif not self.grounded and self.gravity >= 0:
            self.image = self.image_bank[3][0]

    def jump(self):
        pass


    def hit(self):
        pass

    def func_jumped(self):
        self.grounded = False
        self.gravity = -10
        self.jumped = True

    def func_double_jumped(self):
        self.is_double_jumped = True
        self.gravity = -10
        self.jumped = True

    def boundaries(self):
        if self.rect.left <= 0:
            self.rect.left = 0
        if self.rect.right >= 1024:
            self.rect.right = 1024

        if self.is_dashing:
            self.gravity = 0
            self.dy = self.gravity
        else:
            self.gravity += 0.5
            self.dy = self.gravity
            self.rect.centery += self.dy
            self.float = True

        if self.rect.bottom >= 768:
            self.rect.bottom = 768
            self.gravity = 0
            self.dy = self.gravity
            self.grounded = True
            self.is_double_jumped = False
            self.double_jump_index = 0
            self.jumped = False
            self.rolled = False

    def update(self):
        self.controls()
        self.boundaries()
        self.jump()
        if self.flipped:
            self.image_bank = self.flipped_images
        else:
            self.image_bank = self.images
        self.animation()


class Player2(Player):
    def controls(self):
        keys = pygame.key.get_pressed()
        if self.is_dashing:
            self.dash()
            self.cooldown = 3
        else:
            if keys[pygame.K_LEFT]:
                self.idle_index = 0
                self.rect.centerx -= 3
                self.direction = -1
                self.flipped = True
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]

            elif keys[pygame.K_RIGHT]:
                self.idle_index = 0
                self.rect.centerx += 3
                self.direction = 1
                self.flipped = False
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]
            else:
                self.run_index = 0
                self.idle_index += 1 / 3
                if self.idle_index > len(self.image_bank[0]):
                    self.idle_index = 0
                self.image = self.image_bank[0][int(self.idle_index)]

            self.cooldown -= 1 / 60


class Player3(Player):
    def controls(self):
        keys = pygame.key.get_pressed()
        if self.is_dashing:
            self.dash()
            self.cooldown = 3
        else:
            if keys[pygame.K_a]:
                self.idle_index = 0
                self.rect.centerx -= 3
                self.direction = -1
                self.flipped = True
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]

            elif keys[pygame.K_d]:
                self.idle_index = 0
                self.rect.centerx += 3
                self.direction = 1
                self.flipped = False
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]
            else:
                self.run_index = 0
                self.idle_index += 1 / 3
                if self.idle_index > len(self.image_bank[0]):
                    self.idle_index = 0
                self.image = self.image_bank[0][int(self.idle_index)]

            self.cooldown -= 1 / 60


class Player4(Player):
    def controls(self):
        keys = pygame.key.get_pressed()
        if self.is_dashing:
            self.dash()
            self.cooldown = 3
        else:
            if keys[pygame.K_j]:
                self.idle_index = 0
                self.rect.centerx -= 3
                self.direction = -1
                self.flipped = True
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]

            elif keys[pygame.K_l]:
                self.idle_index = 0
                self.rect.centerx += 3
                self.direction = 1
                self.flipped = False
                self.run_index += 1 / 3
                if self.run_index > len(self.image_bank[1]):
                    self.run_index = 0
                self.image = self.image_bank[1][int(self.run_index)]
            else:
                self.run_index = 0
                self.idle_index += 1 / 3
                if self.idle_index > len(self.image_bank[0]):
                    self.idle_index = 0
                self.image = self.image_bank[0][int(self.idle_index)]

            self.cooldown -= 1 / 60

Game().main()
