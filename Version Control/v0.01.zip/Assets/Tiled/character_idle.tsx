<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Idle (32x32)" tilewidth="32" tileheight="32" tilecount="11" columns="11">
 <image source="../../../../Downloads/Pixel Adventure 1/Free/Main Characters/Virtual Guy/Idle (32x32).png" width="352" height="32"/>
</tileset>
