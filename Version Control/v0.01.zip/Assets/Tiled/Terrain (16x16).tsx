<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Terrain (16x16)" tilewidth="16" tileheight="16" tilecount="242" columns="22">
 <image source="../../../../Downloads/Pixel Adventure 1/Free/Terrain/Terrain (16x16).png" trans="ff00ff" width="352" height="176"/>
</tileset>
