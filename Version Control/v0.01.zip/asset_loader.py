import pygame

def asset_load_character(col):
    assets = []
    lists = []
    for i in range(11):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/idle/tile{i}.png').convert_alpha())
    assets.append(lists)
    lists = []
    for i in range(12):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/run/tile{i}.png').convert_alpha())
    assets.append(lists)
    lists = []
    for i in range(1):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/jump/tile{i}.png'))
    assets.append(lists)
    lists = []
    for i in range(1):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/fall/tile0.png'))
    assets.append(lists)
    lists = []
    for i in range(6):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/doublejump/tile{i}.png').convert_alpha())
    assets.append(lists)
    lists = []
    for i in range(7):
        lists.append(pygame.image.load(f'Assets/Graphics/{col}/hit/tile{i}.png').convert_alpha())
    assets.append(lists)
    return assets

def asset_load_character_flipped(col):
    assets = []
    lists = []
    for i in range(11):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/idle/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    lists = []
    for i in range(12):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/run/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    lists = []
    for i in range(1):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/jump/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    lists = []
    for i in range(1):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/fall/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    lists = []
    for i in range(6):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/doublejump/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    lists = []
    for i in range(7):
        lists.append(pygame.transform.flip(pygame.image.load(f'Assets/Graphics/{col}/hit/tile{i}.png').convert_alpha(), True, False))
    assets.append(lists)
    return assets



