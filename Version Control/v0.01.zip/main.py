import pygame
from pytmx.util_pygame import load_pygame
from asset_loader import asset_load_character, asset_load_character_flipped

SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768

class Player(pygame.sprite.Sprite):
    def __init__(self, col, direction=True):
        super().__init__()
        self.image_bank = asset_load_character(col)
        self.flipped_image_bank = asset_load_character_flipped(col)
        self.direction = direction
        self.image = self.image_bank[0][0]
        self.rect = self.image.get_rect(topleft=(0, 0))
        self.rect.width -= 1
        self.hitbox = pygame.Rect(self.rect.centerx, self.rect.centery, int(self.rect.width * 0.5), int(self.rect.height * 0.7))
        self.speed = 3
        self.dx = 0
        self.dy = 0
        self.on_ground = False
        self.gravity = 0.6
        self.jump_strength = -10
        self.running = False
        self.dashing = False
        self.current_action = 0
        self.previous_action = None
        self.index = 0
        self.double_jump = False
        self.rolling = False
        self.dash_counter = 0
        self.dash_cd = 0

    def controls(self):
        self.dx = 0
        if self.dashing:
            if self.direction:
                self.dx += self.speed * 4
                self.dy = 0
                self.dash_counter += 1
                if self.dash_counter >= 5:
                    self.dash_counter = 0
                    self.dashing = False
                    self.dash_cd = 2
            else:
                self.dx -= self.speed * 3
                self.dy = 0
                self.dash_counter += 1
                if self.dash_counter >= 5:
                    self.dash_counter = 0
                    self.dashing = False
                    self.dash_cd = 2
        else:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_KP4] and not keys[pygame.K_KP6]:
                self.dx -= self.speed
                self.direction = False
                self.running = True
            elif keys[pygame.K_KP6] and not keys[pygame.K_KP4]:
                self.dx += self.speed
                self.direction = True
                self.running = True
            else:
                self.running = False
            self.dash_cd -= 1/60



    def apply_gravity(self):
        if not self.dashing:
            self.dy += self.gravity
            if self.dy > 15:
                self.dy = 15

    def animation(self):
        self.index += 1/3
        if not self.dashing:
            if self.on_ground:
                if self.running:
                    if self.direction:
                        self.previous_action = self.current_action
                        self.current_action = 0
                        if self.current_action - self.previous_action != 0:
                            self.index = 0
                        if self.index >= len(self.image_bank[1]):
                            self.index = 0
                        self.image = self.image_bank[1][int(self.index)]
                    else:
                        self.previous_action = self.current_action
                        self.current_action = 1
                        if self.current_action - self.previous_action != 0:
                            self.index = 0
                        if self.index >= len(self.flipped_image_bank[1]):
                            self.index = 0
                        self.image = self.flipped_image_bank[1][int(self.index)]
                else:
                    if self.direction:
                        self.previous_action = self.current_action
                        self.current_action = 2
                        if self.current_action - self.previous_action != 0:
                            self.index = 0
                        if self.index >= len(self.image_bank[0]):
                            self.index = 0
                        self.image = self.image_bank[0][int(self.index)]
                    else:
                        self.previous_action = self.current_action
                        self.current_action = 3
                        if self.current_action - self.previous_action != 0:
                            self.index = 0
                        if self.index >= len(self.flipped_image_bank[0]):
                            self.index = 0
                        self.image = self.flipped_image_bank[0][int(self.index)]
            else:
                if self.double_jump and self.rolling:
                    self.previous_action = self.current_action
                    self.current_action = 9
                    if self.current_action - self.previous_action != 0:
                        self.index = 0
                    if self.index >= len(self.image_bank[4]):
                        self.rolling = False
                        self.index = len(self.image_bank[4]) - 1
                    if self.direction:
                        self.image = self.image_bank[4][int(self.index)]
                    else:
                        self.image = self.flipped_image_bank[4][int(self.index)]
                else:
                    if self.dy <= 0:
                        if self.direction:
                            self.previous_action = self.current_action
                            self.current_action = 4
                            if self.current_action - self.previous_action != 0:
                                self.index = 0
                            if self.index >= len(self.image_bank[2]):
                                self.index = 0
                            self.image = self.image_bank[2][int(self.index)]
                        else:
                            self.previous_action = self.current_action
                            self.current_action = 5
                            if self.current_action - self.previous_action != 0:
                                self.index = 0
                            if self.index >= len(self.flipped_image_bank[2]):
                                self.index = 0
                            self.image = self.flipped_image_bank[2][int(self.index)]
                    else:
                        if self.direction:
                            self.previous_action = self.current_action
                            self.current_action = 6
                            if self.current_action - self.previous_action != 0:
                                self.index = 0
                            if self.index >= len(self.image_bank[3]):
                                self.index = 0
                            self.image = self.image_bank[3][int(self.index)]
                        else:
                            self.previous_action = self.current_action
                            self.current_action = 7
                            if self.current_action - self.previous_action != 0:
                                self.index = 0
                            if self.index >= len(self.flipped_image_bank[3]):
                                self.index = 0
                            self.image = self.flipped_image_bank[3][int(self.index)]
        else:
            self.previous_action = self.current_action
            self.current_action = 8
            self.index = 0


    def update(self, obstacles):
        self.controls()
        self.apply_gravity()
        self.animation()

        self.rect.x += self.dx

        if self.rect.left  < 0:
            self.rect.left = 0
        if self.rect.right   > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        hit_list = pygame.sprite.spritecollide(self, obstacles, False)
        for obstacle in hit_list:
            if self.dx > 0:  # Moving right, push left
                self.rect.right = obstacle.rect.left
            elif self.dx < 0:  # Moving left, push right
                self.rect.left = obstacle.rect.right

        self.rect.y += self.dy
        self.on_ground = False
        hit_list = pygame.sprite.spritecollide(self, obstacles, False)
        for obstacle in hit_list:
            if self.dy > 0:
                self.rect.bottom = obstacle.rect.top
                self.dy = 0
                self.on_ground = True
                self.double_jump = False
            elif self.dy < 0:
                self.rect.top = obstacle.rect.bottom
                self.dy = 0

        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT
            self.dy = 0
            self.on_ground = True
            self.double_jump = False
        self.hitbox.center = self.rect.center


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, image, x, y):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(topleft=(x*16, y*16))


class Game:
    def __init__(self):
        pygame.init()
        self.sw = 1024
        self.sh = 768
        self.screen = pygame.display.set_mode((self.sw, self.sh), vsync=True)
        pygame.display.set_caption("BomberGuy")
        self.clock = pygame.time.Clock()
        self.running = True
        self.all_sprites = pygame.sprite.Group()

        self.player1 = pygame.sprite.GroupSingle()
        self.player1.add(Player("Red", True))
        self.player2 = pygame.sprite.GroupSingle()
        self.player2.add(Player("Blue", True))
        self.player3 = pygame.sprite.GroupSingle()
        self.player3.add(Player("Yellow", True))
        self.player4 = pygame.sprite.GroupSingle()
        self.player4.add(Player("Green", True))

        self.obstacle_group = pygame.sprite.Group()
        self.map = load_pygame('Assets/Tiled/trial.tmx')
        self.create_map()
        self.fps = 60


    def create_map(self):
        for layer in self.map.visible_layers:
            for x, y, image in layer.tiles():
                self.obstacle_group.add(Obstacle(image, x, y))

    def game_loop(self):
        while self.running:
            self.clock.tick(self.fps)
            self.event_handler()
            self.sprite_updates()
            self.custom_draw()
        pygame.quit()

    def event_handler(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_KP8 and not self.player1.sprite.double_jump and not self.player1.sprite.dashing:
                    self.player1.sprite.dy = self.player1.sprite.jump_strength
                    if not self.player1.sprite.on_ground:
                        self.player1.sprite.double_jump = True
                        self.player1.sprite.rolling = True
                    else:
                        self.player1.sprite.on_ground = False
                if event.key == pygame.K_KP5 and self.player1.sprite.dash_cd <= 0:
                    self.player1.sprite.dashing = True

    def sprite_updates(self):
        self.player1.update(self.obstacle_group)

    def custom_draw(self):
        self.screen.fill("Gray")
        self.obstacle_group.draw(self.screen)
        self.player1.draw(self.screen)
        #pygame.draw.rect(self.screen, (255, 0, 0), self.player1.sprite.rect, 1)
        #pygame.draw.rect(self.screen, (0, 255, 0), self.player1.sprite.hitbox, 1)
        pygame.display.update()

if __name__ == '__main__':
    game = Game()
    game.game_loop()